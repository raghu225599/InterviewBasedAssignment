package java1;

import java.util.Scanner;

public class Circle implements Shape{
    double pi=Math.PI;
    Scanner scanner=new Scanner(System.in);
    double r,area,p;
    public Circle(){
        System.out.print("enter the radius: ");
        r=scanner.nextDouble();
    }
    @Override
    public void calculateArea(){
        if(r>0){
            area=pi*r*r;
            System.out.println("area of circle is : "+area);
        }else{
            System.out.println("radius is negative");
        }
    }
    @Override
    public void calculatePerimeter(){
        if(r>0){
            p=2*pi*r;
            System.out.println("perimeter of circle is : "+p);
        }else{
            System.out.println("radius is negative");
        }
    }
}
