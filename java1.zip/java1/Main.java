package java1;

import java.util.Scanner;

public class Main {
    public static void main(String[] args){
        //problem statement
        /***1. Write a Java program that uses polymorphism by defining an interface called Shape
        with methods to calculate the area and perimeter of a shape. Then create classes
        that implement the Shape interface for different types of shapes, such as circles and
        triangles.
        ***/
        Scanner scanner=new Scanner(System.in);
        int num;
        Shape shape;

        x:while (true) {
            System.out.println("to calculate area and perimeter of a circle press 1");
            System.out.println("to calculate area and perimeter of a triangle press 2");
            System.out.println("press 3 for exit");
            System.out.print("enter your choice:");
            num=scanner.nextInt();

            switch (num) {
                case 1:
                    shape = new Circle();
                    shape.calculatePerimeter();
                    shape.calculateArea();
                    break;
                case 2:
                    shape = new Triangle();
                    shape.calculateArea();
                    shape.calculatePerimeter();
                    break;
                case 3:
                    break x;
                default:
                    System.out.println("wrong input,try again");
            }
        }
    }
}