package java1;

public interface Shape {
    void calculateArea();
    void calculatePerimeter();
}
