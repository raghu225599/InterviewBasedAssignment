package java1;

import java.util.Scanner;

public class Triangle implements Shape{
    double p,a,b,c,area,s;
    Scanner scanner=new Scanner(System.in);

    public Triangle(){
        System.out.print("enter the a value:");
        a=scanner.nextDouble();
        System.out.print("enter the b value:");
        b=scanner.nextDouble();
        System.out.print("enter the c value:");
        c=scanner.nextDouble();
    }

    @Override
    public void calculateArea(){
        if(a>=0 & b>=0 & c>=0){
            //Calculate the semi-perimeter of the triangle, s = (a + b + c) / 2.
            s = (a + b + c) / 2;
            //Calculate the area of the triangle, A = √(s(s - a)(s - b)(s - c)).
            area=Math.sqrt(s*(s - a)*(s - b)*(s - c));
            System.out.println("the area of a triangle is :"+area);
        }else{
            if(a<0)
                System.out.println("a is negative");
            if(b<0)
                System.out.println("b is negative");
            if(c<0)
                System.out.println("c is negative");
        }
    }
    @Override
    public void calculatePerimeter(){
        // the three sides of the triangle must be positive numbers.
        if(a>=0 & b>=0 & c>=0){
            //the sum of any two sides of a triangle must be greater than the third side.
            if(a+b>c & b+c>a & a+c>b){
                p=a+b+c;
                System.out.println("Perimeter of a triangle is : "+p);
            }else{
                if (a+b<c)
                    System.out.println("a+b<c");
                if(b+c<a)
                    System.out.println("b+c<a");
                if(a+c<b)
                    System.out.println("a+c<b");
            }
        }else{
            if(a<0)
                System.out.println("a is negative");
            if (b<0)
                System.out.println("b is negative");
            if (c<0)
                System.out.println("c is negative");
        }
    }
}
