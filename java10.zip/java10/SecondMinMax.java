package java10;
import java.util.ArrayList;
import java.util.Scanner;
/**10. Write a Java program that reads a set of integers from the user and stores them in a
List. The program should then find the second largest and second smallest elements
in the List.
*/
public class SecondMinMax {

	public static void main(String[] args) {
		int firstMin,firstMax,secondMin,secondMax;
		Scanner scanner=new Scanner(System.in);
		System.out.print("how many integers you want to enter: ");
		int listSize = scanner.nextInt();
		ArrayList<Integer> list=new ArrayList<>();
		int i=0;
		System.out.println("enter "+listSize+" numbers");
		while(i<listSize) {
			list.add(scanner.nextInt());
			i++;
		}

		firstMin=list.get(0);
		firstMax=list.get(0);
		int indexMax=-1,indexMin=-1;
		for(int j=1;j<list.size();j++) {
			int ele=list.get(j);
			if(ele<firstMin) {
				firstMin = ele;
			}
			if(ele>firstMax) {
				firstMax = ele;
			}
		}
		indexMin=list.indexOf(firstMin);
		list.remove(indexMin);
		indexMax=list.indexOf(firstMax);
		list.remove(indexMax);
		secondMin=list.get(0);
		secondMax=list.get(0);
		for (Integer integer : list) {
			if (integer < secondMin)
				secondMin = integer;
			if (integer > secondMax)
				secondMax = integer;
		}
		System.out.println("second maximum :"+secondMax);
		System.out.println("second minimum :"+secondMin);
	}

}
