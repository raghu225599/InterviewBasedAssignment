package java2;

public class Child extends Parent{
    //when Child class object is created the control will come here, based on the object creation the jvm decides whether the object is with
    //parameterized or zero parameterized constructor and execute the constructor based on the decision, while executing constructors, if we
    // not mention explicitly super method with parameterized or zero parameterized (super() or super(10)) in the first line, then jvm will call
    // internally super method with zero parameterized constructor(super())
    public Child(){
        //super()
        System.out.println("Child class zero parameterized constructor");
    }
    public Child(int num){
        super(10);
        System.out.println("Child class integer parameterized constructor");
    }

    public Child(boolean bool){
        System.out.println("Child class boolean parameterized constructor");
    }
}
