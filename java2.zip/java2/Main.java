package java2;

public class Main {
    public static void main(String[] args) {
        /** problem statement:
         * 2.Write a Java program to invoke parent class constructor from a child class. Create
         * Child class object and parent class constructor must be invoked. Demonstrate by
         * writing a program. Also explain key points about Constructor.
         */

        //This object is of zero parameterized,from here the control will go to Child class and execute zero parameterized constructor
        Child ch=new Child();

        Child ch2=new Child(10);

        Child ch3=new Child(true);
    }
}
