package java2;

public class Parent {
    public Parent(){
        System.out.println("Parent class zero parameterized constructor");
    }
    public Parent(int num){
        System.out.println("parent class integer parameterized constructor");
    }

    public Parent(boolean bool){
        System.out.println("parent class boolean parameterized constructor");
    }
}
