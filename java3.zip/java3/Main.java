package java3;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) throws NegativeIntException{
        Scanner scanner=new Scanner(System.in);
        System.out.println("enter the integer number");
        int num=scanner.nextInt();
        //if it is positive the exit normally, if it is negative integer then the program generates exception
        if(num<0){
            //when we write this line we will get saying that Unhandled exception the solution to that is surround it
            // with try catch or duck the exception the best thing is to do both
            try {
                throw new NegativeIntException("negative integer number");
            }catch(NegativeIntException nie){
                System.out.println(nie.getMessage());
                nie.printStackTrace();
            }
        }
    }
}
