package java3;

public class NegativeIntException extends Exception{
    public NegativeIntException(){

    }

    public NegativeIntException(String msg){
        super(msg);
    }
}
