package java5;

public class InterfaceVsAbstract {
    public static void main(String[] args){
        Vehicle vehicle;
        vehicle=new Bike();
        vehicle.start();
        vehicle.stop();
        vehicle=new Car();
        vehicle.start();
        vehicle.stop();
        Shape shape=new Square(34.5);
        System.out.println("Area of a square "+shape.getArea());
        System.out.println("perimeter of a square "+shape.getPerimeter());
    }
}
/**
 * Interfaces:
 *  if we don't know implementation just we have requirement specification,then we should go for interface
 *  Every method present inside interface is public and abstract, whether we declare it or not
 * we can't declare interface methods with modifiers like private,final,protected,static,synchronized,native,strictfp
 * Every variable in interface is public static final, whether declare or not
 * Every variable in interface is public static final,but we can declare with the modifiers like private,protected,transient,volatile
 * For every interface variable we should perform initialization at the time of declaration because of final
 * Inside interface we cant write static and instance block
 * Inside interface we cant write constructor
 */
interface Vehicle{

    // Vehicle(){} constructor not allowed in interface

    int fuelInLitres = 0;
    //private int variable=0; modifier private not allowed here
    //protected int variable=0; modifier protected not allowed here
    //transient int variable=0; modifier transient not allowed here
    //volatile int variable=0; illegal combination of modifiers: volatile and final

    void start();
    void stop();
    //private void method1(); private method in interfaces should have a body
    //protected void method2(); modifier protected not allowed here
    //static void method2(); static method in interfaces should have a body
    //synchronized void method2(); modifier synchronized not allowed here
    //native void method2(); modifier native not allowed here
    //strictfp void method2(); illegal combination of modifiers: strictfp and abstract
}

class Bike implements Vehicle{

    @Override
    public void start() {
        System.out.println("Bike started");
    }

    @Override
    public void stop() {
        System.out.println("bike stopped");
    }
}
class Car implements Vehicle{

    @Override
    public void start() {
        System.out.println("car started");
    }

    @Override
    public void stop() {
        System.out.println("car stopped");
    }
}


/**
 * Abstract class:
 *  if we are talking about implementation but not completely,then we should go for abstract class
 *  Every method present inside abstract class need not be public and abstract
 * There are no restrictions on abstract class method modifiers
 * Every variable in abstract class need not be public static final
 * no restrictions on access modifiers
 * not required to perform initialization for abstract class variables at the time of declaration
 * inside abstract class we can write static and instance block
 * inside abstract class we can write constructor
 */

abstract class Shape{
    public double side;

    {
        System.out.println("instance block inside shape");
    }

    static{
        System.out.println("static block inside shape");
    }
    public Shape(double side) {
        this.side = side;
    }

    public abstract double getArea();
    public abstract double getPerimeter();
}

class Square extends Shape{

    public Square(double side) {
        super(side);
    }

    @Override
    public double getArea() {
        return side*side;
    }

    @Override
    public double getPerimeter() {
        return 4*side;
    }
}