package java6;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class StreamSortAndFilter {
    public static void main(String[] args){
        ArrayList<Integer> arrayList=new ArrayList<>();
        arrayList.add(89);
        arrayList.add(23);
        arrayList.add(76);
        arrayList.add(54);
        arrayList.add(34);
        arrayList.add(31);

        //sorting the numbers using stream
        List<Integer> sortedList= arrayList.stream().sorted().toList();
        System.out.println(sortedList);

        //filtering the elements based on the condition
        List<Integer> filterList=arrayList.stream().filter(i->i>=50).toList();
        System.out.println(filterList);
    }
}
