package jdbc11;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
/*
 * 
 */
public class ReadOperation {

	public static void main(String[] args) {
		try {
		//step1 load and register the driver
			Class.forName("com.mysql.cj.jdbc.Driver");
			System.out.println("loading the driver");
		//step2 establish the connection with the database
			String url="jdbc:mysql:///employee";
			String userName="root";
			String password="password";
			Connection connection=DriverManager.getConnection(url,userName,password);
			System.out.println("Connection established");
		//step3 create statement/preparedStatement object
			Statement statement=connection.createStatement();
		//step4 execute the query and process the result
			ResultSet resultSet=statement.executeQuery("SELECT sid,sname,Salary from emp");
			System.out.println("SID\tSNAME\tSalary");
			while(resultSet.next()) {
				System.out.println(resultSet.getInt(1)+"\t"+resultSet.getString(2)+"\t"+resultSet.getInt(3));
			}
		//step5 handle SQLException if generated
			System.out.println("SQLException handled....");
		//step6 close the resources
			System.out.println("closing the resources...");
			resultSet.close();
			statement.close();
			connection.close();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

}
