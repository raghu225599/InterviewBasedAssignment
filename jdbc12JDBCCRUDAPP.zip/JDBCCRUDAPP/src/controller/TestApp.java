package controller;
import java.util.Scanner;
import servicelayerfactory.ServiceLayerFactory;
import studentdto.Student;
import servicelayer.IStudentService;
/**12. Write a Java program that uses JDBC to implement a simple CRUD (create, read,
update, delete) application. The program should allow users to add, view, update,
and delete records in a MySQL database table.
*/
public class TestApp {
	
	private static Scanner scanner=null;
	private static IStudentService studentService=null;
	
	public static void main(String[] args) {
		Operations();
	}
	
	public static void Operations() {
		//Menu for the user for the CRUD Operations:
		Integer choice=null;
		scanner=new Scanner(System.in);
		
		b:while(true) {
			System.out.println("----------------------------");
			System.out.println("Press 1 for Insert Operation");
			System.out.println("press 2 for Select Operation");
			System.out.println("press 3 for Update Operation");
			System.out.println("press 4 for Delete Operation");
			System.out.println("press 5 for exit");
			if(scanner!=null) {
				System.out.print("enter your choice::");
				choice=scanner.nextInt();
			}
			
			switch(choice) {
				case 1:
					insertOperation();
					break;
				case 2:
					searchOperation();
					break;
				case 3:
					updateOperation();
					break;
				case 4:
					deleteOperation();
					break;
				case 5:
					System.out.println("You are exited");
					break b;
				default:
					System.out.println("Invalid Operation");
					break;
			}
		}
		
	}

	public static void insertOperation() {
		scanner=new Scanner(System.in);
		String sname=null;
		Integer sage=null;
		String saddress=null;
		String message=null;
		
		if(scanner!=null) {
			System.out.print("enter sname::"); 
			sname=scanner.next();
			
			System.out.print("enter sage::"); 
			sage=scanner.nextInt();
			
			System.out.print("enter saddress::"); 
			saddress=scanner.next();
		}
		
		studentService=ServiceLayerFactory.getStudentService();
		message=studentService.addStudent(sname, sage, saddress);
		
		if(message.equalsIgnoreCase("SUCCESS"))
			System.out.println("record inserted");
		else
			System.out.println("record not inserted");
	}
	
	public static void searchOperation() {
		scanner=new Scanner(System.in);
		Integer sid=null;
		String msg=null;
		if(scanner!=null) {
			System.out.print("enter sid::");
			sid=scanner.nextInt();
		}
		studentService=ServiceLayerFactory.getStudentService();
		Student obj=studentService.searchStudent(sid);
		msg=obj.getMessage();
		if(msg!=null) {
			if(msg.equalsIgnoreCase("success")) {
				System.out.println("-------------------------");
				System.out.println("sname\tsage\tsaddress");
				System.out.println(obj.getSname()+"\t"+obj.getSage()+"\t"+obj.getSaddress());
			}else {
				System.out.println("For the given"+sid+"there is no record present");
			}
		}
	}
	
	public static void updateOperation() {
		scanner=new Scanner(System.in);
		Integer sid=null;
		String sname=null;
		String saddress=null;
		Integer sage=null;
		
		if(scanner!=null) {
			System.out.print("enter sid::");
			sid=scanner.nextInt();
		}
		
		studentService=ServiceLayerFactory.getStudentService();
		if(scanner!=null) {
			System.out.print("enter sid::");
			sid=scanner.nextInt();
			System.out.print("enter sname::");
			sname=scanner.next();
			System.out.print("enter sage::");
			sage=scanner.nextInt();
			System.out.print("enter saddress::");
			saddress=scanner.next();
		}
		
		String message=studentService.updateStudent(sid,sname,sage,saddress);
		if(message.equalsIgnoreCase("success")) {
			System.out.println("record updated successfully....");
		}else {
			System.out.println("record not updated for the given"+sid+"because there may be record is not present");
		}
	}
	
	public static void deleteOperation() {
		scanner=new Scanner(System.in);
		Integer sid=null;
		
		if(scanner!=null) {
			System.out.print("enter sid::");
			sid=scanner.nextInt();
		}
		
		studentService=ServiceLayerFactory.getStudentService();
		
		String message=studentService.deleteStudent(sid);
		if(message.equalsIgnoreCase("success")) {
			System.out.println("record deleted successfully....");
		}else {
			System.out.println("record not deleted for the given"+sid+"because there may be record is not present");
		}
	}
}
