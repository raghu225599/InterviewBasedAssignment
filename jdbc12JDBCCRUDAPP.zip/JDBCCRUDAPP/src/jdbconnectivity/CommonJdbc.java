package jdbconnectivity;

import java.sql.Connection;
import java.sql.DriverManager;
import java.util.Properties;
import java.io.FileReader;
import java.sql.SQLException;
import java.io.FileNotFoundException;
import java.io.IOException;

public class CommonJdbc {
	
	public static Connection getJdbcConnection() throws SQLException{
		
		Connection connection=null;
		FileReader fr=null;
		Properties properties=null;
		
		try {
			fr=new FileReader("F:\\Eclipse java\\JDBCCRUDAPP\\src\\properties\\application.properties");
			properties=new Properties();
			properties.load(fr);
			connection=DriverManager.getConnection(properties.getProperty("url"),properties.getProperty("userName"),properties.getProperty("password"));
		}
		catch(SQLException se) {
			se.printStackTrace();
		}
		catch(FileNotFoundException fe) {
			fe.printStackTrace();
		}
		catch(IOException ie) {
			ie.printStackTrace();
		}
		return connection;
	}
	
	public static void closeResources(Connection connection,java.sql.Statement stmt,java.util.Scanner scanner) throws SQLException{
		try {
			if(connection!=null)
				connection.close();
			if(stmt!=null)
				stmt.close();
			if(scanner!=null)
				scanner.close();
		}
		catch(SQLException se) {
			se.printStackTrace();
		}
	}
}
