package servicelayer;

import databaseaccesslayer.IStudentDao;
import databaseaccesslayerfactory.DatabaseAccessLayerFactory;
import studentdto.Student;

public class StudentServiceImpl implements IStudentService {
	
	IStudentDao studentDao=DatabaseAccessLayerFactory.getStudentDao();
	
	@Override
	public String addStudent(String sname, Integer sage, String saddress) {
		return studentDao.addStudent(sname, sage, saddress);
	}

	@Override
	public Student searchStudent(Integer sid) {
		return studentDao.searchStudent(sid);
	}

	@Override
	public String updateStudent(Integer sid, String sname, Integer sage, String saddress) {
		return studentDao.updateStudent(sid, sname, sage, saddress);
	}

	@Override
	public String deleteStudent(Integer sid) {
		return studentDao.deleteStudent(sid);
	}

}
