package jdbc13;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.PreparedStatement;

public class PostgresqlBatchUpdate {

	public static void main(String[] args) {
		
		try {
			//step1 load and register the driver
				Class.forName("org.postgresql.Driver");
				System.out.println("loading the driver");
			//step2 establish the connection with the database
				String url="jdbc:postgresql://localhost:5432/databasename";
				String userName="root";
				String password="password";
				Connection connection=DriverManager.getConnection(url,userName,password);
				System.out.println("Connection established");
			//step3 create statement/preparedStatement object
				PreparedStatement pstmt=connection.prepareStatement("INSERT INTO tablename(`name`,`age`,`addresss`) VALUES(?,?,?)");
			//step4 execute the query and process the result
				String inputFile="jdbc13\\input.csv";
				BufferedReader reader=new BufferedReader(new FileReader(inputFile));
				String line=null;
				while((line=reader.readLine())!=null) {
					String[] record=line.split(",");
					String name=record[0];
					int age=Integer.parseInt(record[1]);
					String address=record[2];
					pstmt.setString(1, name);
					pstmt.setInt(2, age);
					pstmt.setString(3, address);
				//add the query to batch file
					pstmt.addBatch();
				}
			//executing the queries present in batch file
				pstmt.executeBatch();
				System.out.println("records inserted successfully...");
			//step5 handle SQLException if generated
				System.out.println("SQLException handled....");
			//step6 close the resources
				System.out.println("closing the resources...");
				reader.close();
				pstmt.close();
				connection.close();
			} catch (ClassNotFoundException e) {
				e.printStackTrace();
			} catch (SQLException e) {
				e.printStackTrace();
			} catch (FileNotFoundException e) {
				e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			}
	}

}
