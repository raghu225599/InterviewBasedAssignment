package in.ineuron.contoller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class WelcomeMessage
 */
@WebServlet("/WelcomeMessageWithName")
public class WelcomeMessage extends HttpServlet {
	private static final long serialVersionUID = 1L;
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	PrintWriter out=null;
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		out=response.getWriter();
		String name=request.getParameter("name");
		out.println("<body>");
		out.println("<center>");
		out.println("<h1>Welcome ");
		out.print(name+"</h1>");
		out.println("</center>");
		out.println("</body>");
	}

}
