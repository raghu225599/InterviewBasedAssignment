package jdbc15;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
/**15. Write a Java servlet that reads the data from a MySQL database table and displays it
in an HTML table on the web page. The servlet should use JDBC to connect to the
database and retrieve the data.
*/
@WebServlet(urlPatterns="/servlettable",loadOnStartup=10)
public class ServletHtmlTable extends HttpServlet {
	private static final long serialVersionUID = 1L;
    
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	     // Set the content type and character encoding
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        out.println("<html>");
        out.println("<head>");
        out.println("<title>Database Table</title>");
        out.println("</head>");
        out.println("<body>");

        try {
    	//step1 load and register the driver
			Class.forName("com.mysql.cj.jdbc.Driver");
			System.out.println("loading the driver");
		//step2 establish the connection with the database
			String url="jdbc:mysql:///employee";
			String userName="root";
			String password="password";
			Connection connection=DriverManager.getConnection(url,userName,password);
			System.out.println("Connection established");
		//step3 create statement/preparedStatement object
			Statement statement=connection.createStatement();
		
         // Generating HTML table from the result set
            out.println("<table border='1'>");
            out.println("<tr><th>ID</th><th>Name</th><th>Age</th></tr>");
          //step4 execute the query and process the result
			ResultSet resultSet=statement.executeQuery("SELECT sid,sname,Salary from emp");
			System.out.println("SID\tSNAME\tSalary");
			while(resultSet.next()) {
				int sid = resultSet.getInt(1);
				String sname = resultSet.getString(2);
				int sage = resultSet.getInt(3);
				out.println("<tr>");
                out.println("<td>" + sid + "</td>");
                out.println("<td>" + sname + "</td>");
                out.println("<td>" + sage + "</td>");
                out.println("</tr>");
			}
            out.println("</table>");
        //step5 handle SQLException if generated
			System.out.println("SQLException handled....");
		//step6 close the resources
			System.out.println("closing the resources...");
			resultSet.close();
			statement.close();
			connection.close();
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
            out.println("An error occurred while accessing the database.");
        }

        out.println("</body>");
        out.println("</html>");
	}
}
